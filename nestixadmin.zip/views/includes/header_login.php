<nav class="navbar navbar-expand navbar-dark navbar-inner">  
    <a class="navbar-brand" href="">Nestix Admin Panel</a>
</nav>