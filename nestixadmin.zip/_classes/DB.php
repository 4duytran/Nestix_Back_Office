<?php

    class Db{

        private const HOST_NAME = 'localhost';
        private const DB_NAME = 'nestix';
        private const USER_NAME = 'root';
        private const PWD = '';

        private static $conn = null;

        public static function getConnect(){
            if(is_null(self::$conn))
            {
                try
                {
                    $connection = 'mysql:host='.self::HOST_NAME.';dbname='.self::DB_NAME;
                    self::$conn = new PDO($connection,self::USER_NAME,self::PWD,array(PDO::ATTR_PERSISTENT => true));
                    self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                } 
                catch (PDOException $e)
                {
                    $message = 'Error connection Database ' . $e->getMessage();
                    die($message);  
                }
               self::$conn->exec('SET CHARACTER SET UTF8'); 
            }
            return self::$conn;
        }


    }

?>